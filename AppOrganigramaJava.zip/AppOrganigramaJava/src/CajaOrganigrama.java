import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;

public class CajaOrganigrama extends JPanel {

    private String area;
    private String nombre;
    private String[] jefes;
    private Color color;

    public CajaOrganigrama(String area, String nombre, String[] jefes, Color color) {
        this.area = area;
        this.nombre = nombre;
        this.jefes = jefes;
        this.color = color;

        setOpaque(false);
        setSize(180, 80);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                String jefeSeleccionado = (String) JOptionPane.showInputDialog(
                        null,
                        "Seleccione el jefe:",
                        area,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        jefes,
                        jefes[0]
                );

                if (jefeSeleccionado != null) {

                    String[] opciones = {"Agregar empleado", "Ver empleados"};

                    int accion = JOptionPane.showOptionDialog(
                            null,
                            "¿Qué desea hacer?",
                            "Opciones",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                            null,
                            opciones,
                            opciones[0]
                    );

                    if (accion == 0) {
                        String empleado = JOptionPane.showInputDialog("Ingrese nombre del empleado:");

                        if (empleado != null && !empleado.isEmpty()) {
                            guardar(area, jefeSeleccionado, empleado);
                        }
                    }

                    if (accion == 1) {
                        JOptionPane.showMessageDialog(null,
                                obtener(area, jefeSeleccionado));
                    }
                }
            }
        });
    }

    public static void guardar(String area, String jefe, String empleado) {
        try {
            FileWriter fw = new FileWriter("organigrama.txt", true);
            fw.write(area + "|" + jefe + "|" + empleado + "\n");
            fw.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar");
        }
    }

    public static String obtener(String area, String jefe) {
        StringBuilder sb = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader("organigrama.txt"));
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] p = linea.split("\\|");

                if (p[0].equals(area) && p[1].equals(jefe)) {
                    sb.append("- ").append(p[2]).append("\n");
                }
            }
            br.close();
        } catch (Exception e) {
            return "Sin datos";
        }

        return sb.length() == 0 ? "Sin empleados" : sb.toString();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        g2.setColor(color);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);

        g2.setColor(Color.BLACK);
        g2.drawString(area, 10, 30);
        g2.drawString(nombre, 10, 55);
    }
}