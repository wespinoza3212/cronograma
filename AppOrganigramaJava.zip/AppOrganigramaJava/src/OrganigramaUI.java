import javax.swing.*;
import java.awt.*;

public class OrganigramaUI extends JPanel {

    public OrganigramaUI() {
        setLayout(null);

        // GERENCIA
        CajaOrganigrama gerencia = new CajaOrganigrama(
                "Dirección / Gerencia",
                "Sandra Maria Lemus",
                new String[]{"Sandra Maria Lemus"},
                new Color(235, 173, 238) // colores de RGB //
        );
        gerencia.setBounds(500, 20, 250, 80);

        // NIVEL 2
        CajaOrganigrama resiliencia = new CajaOrganigrama(
                "Resiliencia Digital",
                "Sandra Maria Lemus",
                new String[]{"Sandra Maria Lemus"},
                new Color(200, 220, 240)
        );
        resiliencia.setBounds(50, 180, 200, 80);

        CajaOrganigrama operacion = new CajaOrganigrama(
                "Operación de Servicios",
                "Jairo Josue Velasquez Sican",
                new String[]{
                        "Jairo Josue Velasquez Sican",
                        "Valter Geovanny Lemus Fonseca",
                        "Marvin Antonio Gonzalez",
                        "Edgar Roberto Ruiz Alcantara",
                        "Nestor Abel Villeda Villatoro"
                },
                new Color(200, 240, 200)
        );
        operacion.setBounds(300, 180, 200, 80);

        CajaOrganigrama conocimiento = new CajaOrganigrama(
                "Conocimiento Digital",
                "Sandra Maria Lemus",
                new String[]{
                        "Sandra Maria Lemus",
                        "Oscar Geovany Fuentes Castanon",
                        "Marvel Ivan Soto Peinado"
                },
                new Color(255, 230, 180)
        );
        conocimiento.setBounds(550, 180, 200, 80);

        CajaOrganigrama calidad = new CajaOrganigrama(
                "Control de Calidad de Código",
                "Sandra Maria Lemus",
                new String[]{
                        "Sandra Maria Lemus",
                        "Carlos Alberto Chian Martínez",
                        "Hector Andres Guerra Cortez"
                },
                new Color(220, 210, 250)
        );
        calidad.setBounds(800, 180, 200, 80);

        CajaOrganigrama proyectos = new CajaOrganigrama(
                "Proyectos Ágiles",
                "Sandra Maria Lemus",
                new String[]{"Sandra Maria Lemus"},
                new Color(200, 220, 240)
        );
        proyectos.setBounds(1050, 180, 200, 80);

        // NIVEL 3
        CajaOrganigrama sistema = new CajaOrganigrama(
                "Sistema de Gestión de Servicios",
                "Sandra Maria Lemus",
                new String[]{
                        "Sandra Maria Lemus",
                        "John David Rojas Medina",
                        "Sergio Ramiro Serrano Hernandez",
                        "Juan Jose Garcia Chinchilla"
                },
                new Color(200, 240, 200)
        );
        sistema.setBounds(300, 320, 200, 80);

        CajaOrganigrama certificacion = new CajaOrganigrama(
                "Certificación de Proyectos",
                "Sandra Maria Lemus",
                new String[]{
                        "Sandra Maria Lemus",
                        "Amparo del Rosario Cano Rodríguez de Chinchilla",
                        "Gilberto Ivan Ramirez Aguilar",
                        "Maria Fernanda Charuc Lopez"
                },
                new Color(220, 210, 250)
        );
        certificacion.setBounds(800, 320, 200, 80);

        add(gerencia);
        add(resiliencia);
        add(operacion);
        add(conocimiento);
        add(calidad);
        add(proyectos);
        add(sistema);
        add(certificacion);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Línea vertical central
        g.drawLine(625, 100, 625, 140);

        // Línea horizontal
        g.drawLine(150, 140, 1150, 140);

        // Bajadas nivel 2
        g.drawLine(150, 140, 150, 180);
        g.drawLine(400, 140, 400, 180);
        g.drawLine(650, 140, 650, 180);
        g.drawLine(900, 140, 900, 180);
        g.drawLine(1150, 140, 1150, 180);

        // Subniveles
        g.drawLine(400, 260, 400, 320);
        g.drawLine(900, 260, 900, 320);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Organigrama Completo");
        frame.setSize(1300, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(new OrganigramaUI());
        frame.setVisible(true);
    }
}